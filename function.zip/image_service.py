import json
from PIL.Image import core

def lambda_handler(event, context):
    print(Image.warnings)
    return {
        'statusCode': 200,
        'body': json.dumps(f'{event}')
    }

